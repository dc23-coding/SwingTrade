import React, { useRef, useEffect } from 'react';
import { createChart, addCandlestickSeries } from 'lightweight-charts';

export default function BtcChart({ data }) {
  const containerRef = useRef(null);
  const chartRef = useRef(null);
  const seriesRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;
    // initialize chart once
    chartRef.current = createChart(containerRef.current, {
      width: 800,
      height: 400,
      layout: { background: { color: '#0d0f14' }, textColor: '#d1d1d1' },
      grid: { vertLines: { color: '#323546' }, horzLines: { color: '#323546' } },
    });
    seriesRef.current = chartRef.current.addCandlestickSeries();
  }, []);

  useEffect(() => {
    if (seriesRef.current && Array.isArray(data)) {
      seriesRef.current.setData(data);
    }
  }, [data]);

  useCryptoSocket((tick) => {
  if (seriesRef.current) seriesRef.current.update(tick);
});

  return (
    <div
      ref={containerRef}
      className="w-[800px] h-[400px] bg-black"
    />
  );
}