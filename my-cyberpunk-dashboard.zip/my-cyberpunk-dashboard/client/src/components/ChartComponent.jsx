import { useEffect, useRef } from 'react';

const ChartComponent = ({ timeFrame }) => {
  const chartContainerRef = useRef(null);

  useEffect(() => {
    if (!chartContainerRef.current || typeof LightweightCharts === 'undefined') {
      console.error('Lightweight Charts library not loaded or container not ready');
      return;
    }

    try {
      const chart = LightweightCharts.createChart(chartContainerRef.current, {
        width: window.innerWidth * 0.8,
        height: 500,
        layout: { backgroundColor: '#1a1a1a', textColor: '#d1d4dc' },
        grid: { vertLines: { color: '#333' }, horzLines: { color: '#333' } },
      });

      const candleSeries = chart.addCandlestickSeries({
        upColor: '#00ff99',
        downColor: '#ff3366',
        borderVisible: false,
        wickUpColor: '#00ff99',
        wickDownColor: '#ff3366',
      });

      // Sample data (replace with API data in production)
      const sampleData = [
        { time: '2023-10-01', open: 50000, high: 51000, low: 49500, close: 50800 },
        { time: '2023-10-02', open: 50800, high: 51500, low: 50500, close: 51000 },
        { time: '2023-10-03', open: 51000, high: 52000, low: 50800, close: 51800 },
      ];
      candleSeries.setData(sampleData);

      // Resize chart on window resize
      const handleResize = () => {
        chart.resize(window.innerWidth * 0.8, 500);
      };
      window.addEventListener('resize', handleResize);

      // Cleanup on unmount
      return () => {
        window.removeEventListener('resize', handleResize);
        chart.remove();
      };
    } catch (error) {
      console.error('Error initializing chart:', error);
    }
  }, [timeFrame]); // Re-run effect when timeFrame changes

  return <div ref={chartContainerRef} className="shadow-lg rounded-lg overflow-hidden" />;
};

export default ChartComponent;