import express from 'express';
import axios from 'axios';
const router = express.Router();

router.get('/ohlc', async (req, res) => {
  const { instrument, start, end, limit } = req.query;
  const key = process.env.VITE_COINDESK_API_KEY;
  const url = 'https://data-api.coindesk.com/spot/v1/historical/days';
  const { data } = await axios.get(url, { params: { instrument, start, end, limit, api_key: key } });
  res.json(data);
});

export default router;